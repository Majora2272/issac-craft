# IsaacCraft — Basement I

A Minecraft Java 1.21.4 prototype inspired by The Binding of Isaac.

The prototype adds procedural room runs, Isaac-inspired enemies, collectible run upgrades, tears, bombs and secret rooms while keeping Minecraft mining, crafting, building and destruction.

## Prototype status

- Single-player tested in Minecraft Java 1.21.4.
- Designed for up to four players on a home LAN with individual loot.
- LAN joining has not been tested yet.
- The distributable prototype contains no Isaac game files or extracted Isaac artwork.
- The optional `make_local_art.py` workflow is for an owner’s private Isaac installation only.

See [README.md](README.md) for controls, requirements, testing and limitations.
