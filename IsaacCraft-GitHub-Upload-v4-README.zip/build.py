"""Sheet-driven vanilla Minecraft 1.21.4 floor. Standard library only.

Preflight runs before any generated output is written. Every sheet cell is checked
for presence/type; references and supported handlers are checked. Runtime checks
are a separate release gate and must not be confused with this schema preflight.
"""
import json, pathlib, re, sys, zipfile
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'build'/'IsaacCraft'
S={p.stem:json.loads(p.read_text()) for p in (ROOT/'sheets').glob('*.json')}
SCHEMAS={
 'rooms':dict(id=str,index=int,name=str,x=int,z=int,kind=str,enemy=str,count=int,reward=bool,palette=str),
 'doors':dict(id=str,**{'from':str},to=str,secret=bool),
 'enemies':dict(id=str,entity=str,name=str,health=int,speed=float,damage=int,scale=float,color=str,behavior=str),
 'items':dict(id=str,index=int,name=str,description=str,stat=str,amount=int,cap=int,icon=str,color=str),
 'systems':dict(id=str,max_players=int,floor_y=int,ceiling_y=int,room_radius=int,default_damage=int,default_cooldown=int,default_health=int,default_bombs=int,ray_steps=int,ray_step=float,bomb_fuse=int,revive_health=int,boss_stomp_ticks=int,boss_stomp_radius=int,boss_stomp_damage=int,label_scale=float,label_alignment=str),
 'hooks':dict(id=str,event=str,handler=str,purpose=str),
 'visuals':dict(id=str,kind=str,target=str,texture=str,parent=str,variants=str)}
SCHEMAS['systems'].update(wall_lining=int,door_half_length=int,tear_damage_type=str,door_endcaps=bool)
SCHEMAS['grid']=dict(id=str,x=int,z=int,neighbors=list)
SCHEMAS['generation']=dict(id=str,start=str,order=list,boss_farthest=bool,combat_min=int,grid_spacing=int,clear_min=int,clear_max=int)
SCHEMAS['enemies'].update(shot_interval=int,bullet_damage=int,bullet_speed=float,bullet_life=int,sprite_scale=float,sprite_y=float)
errors=[]; cells=[]
for table,schema in SCHEMAS.items():
 rows=S.get(table,[]); ids=set()
 if not rows: errors.append(f'{table}: empty/missing sheet')
 for row in rows:
  if row.get('id') in ids: errors.append(f'{table}: duplicate id {row.get("id")}')
  ids.add(row.get('id'))
  for col,t in schema.items():
   ok=type(row.get(col)) is t and row.get(col)!=''
   cells.append({'cell':f'{table}.{row.get("id")}.{col}','checked':ok,'basis':'schema/type; design value, not gameplay evidence'})
   if not ok: errors.append(f'{table}.{row.get("id")}.{col}: unfilled or invalid')
  if set(row)!=set(schema): errors.append(f'{table}.{row.get("id")}: unexpected/missing columns')
rooms={r['id']:r for r in S['rooms']}; enemies={r['id']:r for r in S['enemies']}
for r in rooms.values():
 if r['enemy']!='none' and r['enemy'] not in enemies: errors.append(f'rooms.{r["id"]}.enemy unresolved')
 if r['kind'] not in ['safe','combat','treasure','boss','secret']: errors.append(f'room {r["id"]}: unsupported kind')
for d in S['doors']:
 for c in ['from','to']:
  if d[c] not in rooms: errors.append(f'doors.{d["id"]}.{c}: unresolved')
 if d['from'] in rooms and d['to'] in rooms:
  a,b=rooms[d['from']],rooms[d['to']]
  if abs(a['x']-b['x'])+abs(a['z']-b['z'])!=24: errors.append(f'door {d["id"]}: not adjacent')
for i in S['items']:
 if i['stat'] not in ['ic.damage','ic.rate','ic.hearts','ic.armor','ic.speed','ic.bombs','ic.double','ic.piercing','ic.poison']: errors.append(f'item {i["id"]}: unsupported stat')
for e in S['enemies']:
 if e['behavior'] not in ['chase','shoot','stomp','radial']: errors.append(f'enemy {e["id"]}: unsupported behavior')
for v in S['visuals']:
 if v['kind'] not in ['item','block']: errors.append(f'visual {v["id"]}: unsupported kind')
if sorted(r['index'] for r in S['rooms'])!=list(range(len(rooms))): errors.append('Room indices must be contiguous')
if sorted(r['index'] for r in S['items'])!=list(range(len(S['items']))): errors.append('Item indices must be contiguous')
grid={r['id']:r for r in S['grid']}; gen=S['generation'][0]
if gen['start'] not in grid: errors.append('generation.start unresolved')
if set(gen['order'])!=set(rooms) or len(gen['order'])!=len(rooms): errors.append('generation.order must include every room exactly once')
for cell in grid.values():
 for ref in cell['neighbors']:
  if ref not in grid: errors.append(f'grid.{cell["id"]}: unresolved neighbor {ref}')
  elif abs(grid[ref]['x']-cell['x'])+abs(grid[ref]['z']-cell['z'])!=gen['grid_spacing']: errors.append(f'grid.{cell["id"]}: non-adjacent neighbor')
if gen['combat_min']!=sum(r['kind']=='combat' for r in rooms.values()):errors.append('generation.combat_min does not match room sheet')
audit={'passed':not errors,'cells':cells,'findings':errors,'runtimeVerified':False}
(ROOT/'preflight.json').write_text(json.dumps(audit,indent=2))
if errors: sys.exit('\n'.join(errors))
print(f'Preflight: {len(cells)} filled, typed cells; all sheet references resolved.')
if '--preflight' in sys.argv: sys.exit(0)
C=S['systems'][0]; Y=C['floor_y']; H=C['ceiling_y']; R=C['room_radius']
FUN={}
def j(v): return json.dumps(v,separators=(',',':'),ensure_ascii=True)
def txt(s,color='white'): return j({'text':s,'color':color,'italic':False})
def fn(name,lines): FUN[name]=[s for s in lines if s]
def fill(x1,y1,z1,x2,y2,z2,b): return f'fill {x1} {y1} {z1} {x2} {y2} {z2} minecraft:{b}'
def title(s,sub='',color='#e9c793'): return [f'title @a title {txt(s,color)}',f'title @a subtitle {txt(sub,"#aea5b9")}']
def bounds(r): return f'x={r["x"]-8},y={Y+1},z={r["z"]-8},dx=16,dy=6,dz=16'
def doorbox(d):
 a,b=rooms[d['from']],rooms[d['to']]; x=(a['x']+b['x'])//2; z=(a['z']+b['z'])//2
 n=C['door_half_length']
 return (x-1,Y+1,z-n,x+1,Y+4,z+n) if a['x']==b['x'] else (x-n,Y+1,z-1,x+n,Y+4,z+1)
def doors_for(r,block): return [fill(*doorbox(d),block) for d in S['doors'] if not d['secret'] and r['id'] in [d['from'],d['to']]]
stats=['damage','rate','hearts','armor','speed','bombs','cd','rand','room','step','hit','timer','state','loot','count','fuse','runid']
fn('load',[*(f'scoreboard objectives add ic.{v} dummy' for v in stats),
 'scoreboard objectives add ic.use minecraft.used:minecraft.carrot_on_a_stick',
 'scoreboard objectives add ic.bomb minecraft.used:minecraft.warped_fungus_on_a_stick',
 'scoreboard objectives add ic.death deathCount','scoreboard objectives add ic.restart trigger',
 'bossbar add ic:boss {"text":"THE HOLLOW"}','bossbar set ic:boss color red',
 'execute unless score #built ic.state matches 1 run function ic:restart'])
build=['gamerule doDaylightCycle false','time set midnight','gamerule doWeatherCycle false','weather clear','gamerule doMobSpawning false','gamerule doPatrolSpawning false','gamerule doTraderSpawning false','gamerule keepInventory true','gamerule doImmediateRespawn true','gamerule mobGriefing true','gamerule doInsomnia false','gamerule fallDamage false','gamerule commandBlockOutput false','gamerule sendCommandFeedback false','difficulty normal',f'setworldspawn 0 {Y+1} 0','gamerule spawnRadius 0','forceload add -16 -64 64 16', 'kill @e[tag=ic.entity]', 'kill @e[type=item]','kill @e[type=tnt]', 'bossbar set ic:boss visible false']
for r in rooms.values():
 x,z=r['x'],r['z']; inner=R-1-C['wall_lining']; lines=[fill(x-R,Y-2,z-R,x+R,H+1,z+R,'bedrock'), fill(x-R+1,Y-1,z-R+1,x+R-1,H,z+R-1,r['palette']),fill(x-inner,Y+1,z-inner,x+inner,H-1,z+inner,'air')]
 # A geometric inset floor and warm wall lights, with vulnerable interior details.
 lines += [fill(x-7,Y,z-7,x+7,Y,z+7,'polished_andesite'), fill(x-5,Y,z-5,x+5,Y,z+5,'deepslate_tiles'),fill(x-2,Y,z-2,x+2,Y,z+2,'chiseled_stone_bricks')]
 for dx in [-8,8]:
  for dz in [-8,8]:
   lines += [fill(x+dx,Y+1,z+dz,x+dx,H-1,z+dz,'polished_basalt'),f'setblock {x+dx} {Y+3} {z+dz} shroomlight',f'setblock {x+dx} {Y+1} {z+dz} cracked_stone_bricks']
 for dx,dz in [(-5,4),(5,-4)]:
  lines += [fill(x+dx,Y+1,z+dz,x+dx+1,Y+2,z+dz+1,'cobblestone'),f'setblock {x+dx} {Y+2} {z+dz} coal_ore',f'setblock {x+dx+1} {Y+1} {z+dz} iron_ore']
 scale=C['label_scale']
 lines += [f'summon text_display {x} {Y+5} {z} '+ '{Tags:["ic.entity"],billboard:"center",text:'+"'"+txt(r['name'],'#e4cda1')+"'"+f',alignment:"{C["label_alignment"]}",background:0,shadow:1b,view_range:0.7f,transformation:{{scale:[{scale}f,{scale}f,{scale}f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}}}',f'scoreboard players set #{r["id"]} ic.state 0']
 if r['kind']=='safe':
  lines += [f'setblock {x-3} {Y+1} {z+6} crafting_table',f'setblock {x-2} {Y+1} {z+6} furnace',f'setblock {x+3} {Y+1} {z+6} oak_log',f'setblock {x+3} {Y+2} {z+6} oak_log',f'setblock {x+4} {Y+1} {z+6} oak_log']
 if r['kind'] in ['treasure','secret']:
  lines += [f'setblock {x} {Y+1} {z} gilded_blackstone',f'setblock {x} {Y+2} {z} enchanting_table']
 fn('world/'+r['id'],lines); build += ['function ic:world/'+r['id']]
for d in S['doors']:
 box=doorbox(d); x1,y1,z1,x2,y2,z2=box
 vertical=rooms[d['from']]['x']==rooms[d['to']]['x']
 ex=1 if vertical or C['door_endcaps'] else 0
 ez=1 if not vertical or C['door_endcaps'] else 0
 lines=[fill(x1-ex,Y-1,z1-ez,x2+ex,H,z2+ez,'bedrock'),fill(x1,Y,z1,x2,Y,z2,'polished_blackstone_bricks'),fill(*box,'air')]
 if d['secret']:
  lines += [fill(*box,'bedrock'),fill(-1,Y+1,-33,1,Y+3,-33,'cracked_stone_bricks')]
 fn('doors/'+d['id'],lines);build+=['function ic:doors/'+d['id']]
build+=['scoreboard players set #built ic.state 1','scoreboard players set #active ic.room -1','scoreboard players set #secret ic.state 0','scoreboard players add #run ic.runid 1','scoreboard players set #clock ic.timer 0','tag @a remove ic.player','gamemode survival @a','clear @a','tp @a 0 65 3 180 0','scoreboard players set @a ic.restart 0','execute as @a run function ic:init',*title('BASEMENT I','Four souls. One way down.')]
fn('restart',build)
init=[f'scoreboard players set @s ic.{v} {val}' for v,val in [('damage',C['default_damage']),('rate',C['default_cooldown']),('hearts',C['default_health']),('bombs',C['default_bombs']),('armor',0),('speed',0),('cd',0),('death',0),('use',0),('bomb',0),('loot',0),('room',-1)]]
init+=['tag @s add ic.player','scoreboard players operation @s ic.runid = #run ic.runid','gamemode survival @s',f'tp @s 0 {Y+1} 3 180 0',f'spawnpoint @s 0 {Y+1} 3','effect clear @s','attribute @s minecraft:max_health base set 20','attribute @s minecraft:armor base set 0','attribute @s minecraft:movement_speed base set 0.1','effect give @s minecraft:instant_health 1 5 true','clear @s',
 'give @s carrot_on_a_stick[minecraft:custom_name=\'{"text":"TEARS • hold right click","color":"aqua","italic":false}\',minecraft:unbreakable={}]',
 'give @s warped_fungus_on_a_stick[minecraft:custom_name=\'{"text":"BOMB • right click, then move!","color":"gold","italic":false}\',minecraft:unbreakable={}]',
 'give @s stone_pickaxe','give @s stone_sword','give @s bread 12','give @s cobblestone 12','give @s torch 12',
 f'tellraw @s {txt("BASEMENT I  |  Tears: right click • Bomb: slot 2 • Mine & craft normally","#88dcd4")}',f'tellraw @s {txt("Stay together. Room clears give each player a private random upgrade. Fallen friends return on clear.","#c1b6ce")}',f'tellraw @s {txt("Cracked northern walls may hide secrets. /trigger ic.restart begins a fresh run.","#e2c48d")}' ]
fn('init',init)
FUN['init']=['scoreboard players set #admitted ic.count 0','execute as @a[tag=ic.player] run scoreboard players add #admitted ic.count 1',f'execute if score #admitted ic.count matches {C["max_players"]}.. run return run function ic:overflow',*FUN['init']]
fn('overflow',['scoreboard players operation @s ic.runid = #run ic.runid','gamemode spectator @s',f'tellraw @s {txt("This floor supports four players. You are watching this run.","yellow")}'])
tick=['scoreboard players add #clock ic.timer 1','execute as @a unless score @s ic.runid = #run ic.runid run function ic:init','scoreboard players enable @a ic.restart','execute if entity @a[scores={ic.restart=1..}] run function ic:restart','scoreboard players remove @a[scores={ic.cd=1..}] ic.cd 1','execute as @a[tag=ic.player,gamemode=survival,scores={ic.use=1..,ic.cd=0}] at @s run function ic:shoot','scoreboard players set @a ic.use 0','execute as @a[tag=ic.player,gamemode=survival,scores={ic.bomb=1..,ic.bombs=1..}] at @s run function ic:bomb','scoreboard players set @a ic.bomb 0','execute as @a[tag=ic.player,scores={ic.death=1..}] run function ic:death', 'execute if score #active ic.room matches 0.. unless entity @a[tag=ic.player,gamemode=survival] run function ic:wipe','execute as @e[tag=ic.bomb] at @s run function ic:bomb_tick',
 'execute as @a[tag=ic.player] run effect give @s saturation 1 0 true', 'execute as @a[tag=ic.player] run effect give @s night_vision 12 0 true']
for r in rooms.values():
 if r['kind'] in ['combat','boss']:
  tick += [f'execute if score #active ic.room matches -1 if score #{r["id"]} ic.state matches 0 if entity @a[tag=ic.player,gamemode=survival,{bounds(r)}] run function ic:room/{r["id"]}/start',f'execute if score #active ic.room matches {r["index"]} unless entity @e[tag=ic.enemy] run function ic:room/{r["id"]}/clear']
 if r['kind'] in ['treasure','secret']:
  tick += [f'execute as @a[tag=ic.player,gamemode=survival,{bounds(r)},tag=!ic.{r["id"]}] run function ic:room/{r["id"]}/treasure']
tick += ['execute as @e[tag=ic.boss] at @s run function ic:boss_tick','execute if score #clock ic.timer matches 20.. run function ic:second']
fn('tick',tick)
fn('second',['scoreboard players set #clock ic.timer 0','execute as @a[tag=ic.player] run function ic:stats','execute as @a[tag=ic.player] run title @s actionbar '+j([{'text':'BASEMENT I  ','color':'gold'},{'text':'DMG ','color':'gray'},{'score':{'name':'@s','objective':'ic.damage'}},{'text':'  TEARS ','color':'aqua'},{'score':{'name':'@s','objective':'ic.rate'}},{'text':'t  BOMBS ','color':'yellow'},{'score':{'name':'@s','objective':'ic.bombs'}}])])
fn('stats',[*(f'execute if score @s ic.hearts matches {n} run attribute @s minecraft:max_health base set {n}' for n in range(20,37,2)),*(f'execute if score @s ic.armor matches {n} run attribute @s minecraft:armor base set {n}' for n in range(0,13,2)),*(f'execute if score @s ic.speed matches {n} run attribute @s minecraft:movement_speed base set {0.1+n*0.005:.3f}' for n in range(5))])
for e in S['enemies']:
 attrs=[{'id':'minecraft:max_health','base':e['health']},{'id':'minecraft:movement_speed','base':e['speed']},{'id':'minecraft:attack_damage','base':e['damage']},{'id':'minecraft:scale','base':e['scale']}]
 # 1.21.4 entity attributes use the lower-case schema.
 nbt='{Tags:["ic.entity","ic.enemy"'+(',"ic.boss"' if e['behavior']=='stomp' else '')+'],PersistenceRequired:1b,Health:'+str(e['health'])+'f,CustomName:'+"'"+txt(e['name'],e['color'])+"'"+',CustomNameVisible:1b,attributes:'+j(attrs)+'}'
 fn('enemy/'+e['id'],[f'summon {e["entity"]} ~ ~ ~ {nbt}'])
for r in rooms.values():
 if r['kind'] in ['combat','boss']:
  x,z=r['x'],r['z']; start=[f'scoreboard players set #active ic.room {r["index"]}',f'scoreboard players set #{r["id"]} ic.state 1',f'tp @a[tag=ic.player] {x} {Y+1} {z+6} 180 0',*doors_for(r,'bedrock'),*title(r['name'],'Clear the room to claim your own reward.')]
  for i in range(r['count']):
   start += [f'execute positioned {x-4+i*3} {Y+1} {z-4} run function ic:enemy/{r["enemy"]}']
  start+=['scoreboard players set #players ic.count 0','execute as @a[tag=ic.player] run scoreboard players add #players ic.count 1']
  if r['kind']=='boss': start += ['bossbar set ic:boss visible true','bossbar set ic:boss players @a',f'bossbar set ic:boss max {enemies[r["enemy"]]["health"]}','scoreboard players set @e[tag=ic.boss] ic.timer 0']
  else:
   for n in range(2,C['max_players']+1): start += [f'execute if score #players ic.count matches {n}.. positioned {x+5} {Y+1} {z-5+n*2} run function ic:enemy/{r["enemy"]}']
  fn('room/'+r['id']+'/start',start)
  clear=[f'scoreboard players set #{r["id"]} ic.state 2','scoreboard players set #active ic.room -1',*doors_for(r,'air'),f'execute as @a[tag=ic.player,gamemode=spectator] run function ic:revive',f'tp @a[tag=ic.player] {x} {Y+1} {z+4}', 'execute as @a[tag=ic.player] run function ic:reward',f'playsound minecraft:ui.toast.challenge_complete master @a {x} {Y+1} {z} 0.7 1.2']
  if r['kind']=='boss': clear += ['bossbar set ic:boss visible false',*title('BASEMENT CLEARED','A little braver. A little stranger.','#eed395'),f'tellraw @a {txt("Floor complete! Explore missed secrets, or /trigger ic.restart for another run.","#e4c689")}']
  else: clear+=title('ROOM CLEARED','An upgrade for every soul.','#a2d4b0')
  fn('room/'+r['id']+'/clear',clear)
 if r['kind'] in ['treasure','secret']:
  fn('room/'+r['id']+'/treasure',[f'tag @s add ic.{r["id"]}','function ic:reward','give @s iron_ingot 3','give @s oak_log 3','scoreboard players add @s ic.bombs 1',f'tellraw @s {txt("Your private cache: an upgrade, crafting supplies and a bomb.","#e5cc90")}'])
fn('reward',[f'execute store result score @s ic.rand run random value 0..{len(S["items"])-1}',*(f'execute if score @s ic.rand matches {i["index"]} run function ic:item/{i["id"]}' for i in S['items']),'function ic:stats','effect give @s instant_health 1 0 true'])
for i in S['items']:
 op='add' if i['amount']>=0 else 'remove'
 fn('item/'+i['id'],[f'scoreboard players {op} @s {i["stat"]} {abs(i["amount"])}', f'execute if score @s {i["stat"]} matches '+(f'..{i["cap"]-1}' if i['amount']<0 else f'{i["cap"]+1}..')+f' run scoreboard players set @s {i["stat"]} {i["cap"]}',f'tellraw @s {j([{ "text":i["name"]+"  ","color":i["color"]},{"text":i["description"],"color":"gray"}])}',f'playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.8 1.2'])
fn('shoot',['scoreboard players operation @s ic.cd = @s ic.rate','scoreboard players set @s ic.step 0','scoreboard players set @s ic.hit 0','tag @e[tag=ic.target] remove ic.target','execute anchored eyes positioned ^ ^ ^0.6 run function ic:ray','playsound minecraft:entity.snowball.throw player @s ~ ~ ~ 0.3 1.4'])
fn('ray',['particle minecraft:dust{color:[0.25,0.8,0.95],scale:0.65} ~ ~ ~ 0 0 0 0 1 force','scoreboard players add @s ic.step 1','execute if entity @e[tag=ic.enemy,dx=0,dy=0,dz=0] run function ic:hit',f'execute if score @s ic.hit matches 0 if score @s ic.step matches ..{C["ray_steps"]} if block ~ ~ ~ #ic:ray_pass run execute positioned ^ ^ ^{C["ray_step"]} run function ic:ray'])
fn('hit',['scoreboard players set @s ic.hit 1','tag @e[tag=ic.enemy,dx=0,dy=0,dz=0,sort=nearest,limit=1] add ic.target',*(f'execute if score @s ic.damage matches {n} run damage @e[tag=ic.target,limit=1] {n} {C["tear_damage_type"]} by @s' for n in range(1,13)),'tag @e[tag=ic.target] remove ic.target'])
fn('bomb',['scoreboard players remove @s ic.bombs 1',f'execute anchored feet positioned ^ ^ ^2 run summon marker ~ ~0.2 ~ {{Tags:["ic.entity","ic.bomb","ic.new"]}}',f'scoreboard players set @e[tag=ic.new] ic.fuse {C["bomb_fuse"]}','tag @e[tag=ic.new] remove ic.new','playsound minecraft:entity.tnt.primed master @a[distance=..24] ~ ~ ~ 0.6 1'])
fn('bomb_tick',['scoreboard players remove @s ic.fuse 1','particle minecraft:smoke ~ ~0.3 ~ 0.1 0.15 0.1 0.01 4 force','particle minecraft:dust{color:[1.0,0.5,0.1],scale:1.4} ~ ~0.3 ~ 0 0 0 0 1 force','execute if score @s ic.fuse matches ..0 run function ic:explode'])
secretbox=doorbox(next(d for d in S['doors'] if d['secret']))
fn('explode',['execute if score #secret ic.state matches 0 positioned 0 65 -34 if entity @s[distance=..5] run function ic:secret_open','summon tnt ~ ~ ~ {fuse:0}','kill @s'])
fn('secret_open',[fill(*secretbox,'air'),'scoreboard players set #secret ic.state 1',*title('A HIDDEN WAY','Something waits behind the cracks.','#d7a5e6')])
fn('boss_tick',['execute store result bossbar ic:boss value run data get entity @s Health 1','scoreboard players add @s ic.timer 1',f'execute if score @s ic.timer matches {C["boss_stomp_ticks"]-20} run playsound minecraft:entity.iron_golem.attack hostile @a ~ ~ ~ 1 0.6',f'execute if score @s ic.timer matches {C["boss_stomp_ticks"]-20}.. run particle minecraft:dust{{color:[0.9,0.15,0.1],scale:1.5}} ~ ~0.2 ~ 3 0.1 3 0 30 force',f'execute if score @s ic.timer matches {C["boss_stomp_ticks"]}.. run function ic:stomp'])
fn('stomp',[f'execute as @a[gamemode=survival,distance=..{C["boss_stomp_radius"]}] run damage @s {C["boss_stomp_damage"]} minecraft:mob_attack','particle minecraft:explosion ~ ~1 ~ 2 0.1 2 0 5 force','playsound minecraft:entity.generic.explode master @a ~ ~ ~ 0.8 0.7','scoreboard players set @s ic.timer 0'])
fn('death',['scoreboard players set @s ic.death 0','gamemode spectator @s',f'tellraw @s {txt("Your soul remains. Your friends can bring you back by clearing this room.","#b9a8d9")}', 'execute if score #active ic.room matches -1 run function ic:revive'])
fn('revive',['gamemode survival @s','effect give @s instant_health 1 4 true','effect give @s resistance 4 4 true'])
fn('wipe',['function ic:restart',*title('THE DARKNESS WON','A fresh run. Try a different combination.','#d78d9b')])
# Generate the procedural dungeon and expanded combat from their sheets.
from expansion import expand
expand(S,FUN,fn,j,txt,title,C)
# Hook and data records are generated directly from every sheet row.
for table,rows in S.items():
 for row in rows: fn(f'records/{table}/{row["id"]}',[f'data modify storage ic:sheets {table}.{row["id"]} set value {j(row)}'])
FUN['load']=[*FUN['load'],*(f'function ic:records/{table}/{r["id"]}' for table,rows in S.items() for r in rows)]
FUN['init'] += ['tag @s remove ic.treasure','tag @s remove ic.secret']
# Resolve every function reference before writing a build.
for name,lines in FUN.items():
 for line in lines:
  for ref in re.findall(r'\bfunction ic:([a-z0-9_/]+)',line):
   if ref not in FUN: errors.append(f'{name}: unresolved function ic:{ref}')
for h in S['hooks']:
 if h['handler'].removeprefix('ic:') not in FUN: errors.append(f'hook {h["id"]}: unresolved handler')
if errors: sys.exit('\n'.join(errors))
for name,lines in FUN.items():
 path=OUT/'data'/'ic'/'function'/(name+'.mcfunction'); path.parent.mkdir(parents=True,exist_ok=True)
 path.write_text('# Generated from sheets by build.py; do not edit.\n'+'\n'.join(lines)+'\n',encoding='utf-8')
def put(path,data):
 p=OUT/path; p.parent.mkdir(parents=True,exist_ok=True);p.write_text(j(data),encoding='utf-8')
put('pack.mcmeta',{'pack':{'pack_format':61,'description':'IsaacCraft • Basement I • 1–4 LAN players • DEVELOPMENT'}})
for hook in S['hooks']:
 if hook['event'] in ['minecraft:load','minecraft:tick']: put('data/minecraft/tags/function/'+hook['id']+'.json',{'values':[hook['handler']]})
put('data/ic/tags/block/ray_pass.json',{'values':['minecraft:air','minecraft:cave_air','minecraft:void_air','minecraft:torch','minecraft:wall_torch','minecraft:water']})
# Use Minecraft's existing magic type; a custom registry triggers an experimental
# world confirmation on every launch. The cooldown tag is scoped to this world.
obsolete=OUT/'data/ic/damage_type/tear.json'
if obsolete.exists(): obsolete.unlink()
put('data/minecraft/tags/damage_type/bypasses_cooldown.json',{'values':[C['tear_damage_type']]})
with zipfile.ZipFile(ROOT/'IsaacCraft-dev.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(OUT.rglob('*')):
  if p.is_file():
   if p.suffix=='.mcfunction' and p.relative_to(OUT/'data/ic/function').with_suffix('').as_posix() not in FUN: continue
   z.write(p,p.relative_to(OUT).as_posix())
print(f'Generated {len(FUN)} functions. DEVELOPMENT package only; gameplay and install not yet verified.')
resources={'pack.mcmeta':{'pack':{'pack_format':46,'description':'IsaacCraft Basement I • icons and dungeon masonry'}}}
for v in S['visuals']:
 if v['kind']=='item':
  resources[f'assets/minecraft/items/{v["target"]}.json']={'model':{'type':'minecraft:model','model':f'ic:item/{v["id"]}'}}
  resources[f'assets/ic/models/item/{v["id"]}.json']={'parent':v['parent'],'textures':{'layer0':v['texture']}}
 else:
  resources[f'assets/minecraft/models/block/{v["target"]}.json']={'parent':v['parent'],'textures':{'all':v['texture']}}
  if v['variants']=='uniform': resources[f'assets/minecraft/blockstates/{v["target"]}.json']={'variants':{'':{'model':f'minecraft:block/{v["target"]}'}}}
for item in S['items']:
 resources[f'assets/ic/items/collectible/{item["id"]}.json']={'model':{'type':'minecraft:model','model':f'ic:item/collectible/{item["id"]}'}}
 resources[f'assets/ic/models/item/collectible/{item["id"]}.json']={'parent':'minecraft:item/generated','textures':{'layer0':f'minecraft:item/{item["icon"]}'}}
for e in S['enemies']:
 resources[f'assets/ic/items/enemy/{e["id"]}.json']={'model':{'type':'minecraft:model','model':f'ic:item/enemy/{e["id"]}'}}
 resources[f'assets/ic/models/item/enemy/{e["id"]}.json']={'parent':'minecraft:item/generated','textures':{'layer0':'minecraft:item/spider_eye' if e['entity']=='spider' else 'minecraft:item/rotten_flesh'}}
with zipfile.ZipFile(ROOT/'IsaacCraft-Resources-dev.zip','w',zipfile.ZIP_DEFLATED) as z:
 for path,value in resources.items():z.writestr(path,j(value))
print('Resource pack generated; references installed Minecraft textures, bundles no game assets.')
