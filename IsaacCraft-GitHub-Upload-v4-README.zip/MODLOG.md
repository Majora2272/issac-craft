# IsaacCraft development journal

Working title only; listing title, credits attribution, license and remix permission await user choice.

## Agreed scope
Minecraft Java 1.21.4 in a separate Prism instance. One polished Isaac-style floor; up to four players on the same home network; individual loot and stacking upgrades. Room/floor progression, explosive secret-room entrances, breakable interiors, mining and crafting. Isaac is inspiration for this slice, not a required running companion. No extracted game assets may ship. Full recreation is a long-term aspiration, not the first release.

## Route
Vanilla Java datapack plus original world: no Fabric/Forge dependency because Melty installs neither automatically. JSON sheets generate functions and runtime records. Dedicated vanilla server used as command parser and simulation oracle. Prism client used for visual and gameplay checks. LAN join handling and Melty install remain unverified. Never advertise internet co-op.

## Local setup
Original Prism instance: C:/Users/tonyl/AppData/Roaming/PrismLauncher/instances/1.20.4 (unchanged).
New instance: C:/Users/tonyl/AppData/Roaming/PrismLauncher/instances/IsaacCraft-1.21.4.
Toolkit: work/universal-modder, Python venv work/toolkit-env. Toolkit dependencies installed from PyPI. CLI run as python -m um (bin/um is a Bash wrapper).
Pristine backups: work/toolkit-state/backups/prism-original and isaaccraft-pristine-instance.
Java: Temurin 21 JRE downloaded from Adoptium official API, SHA-256 verified, under work/java21. Official Mojang 1.21.4 server SHA-1 verified, work/server/server.jar. Both are local test dependencies, not release files.
Isaac was found at the supplied Steam path on the later scan; native executable with Lua DLLs. No modification to Isaac.
Toolkit scan crashed while enumerating inaccessible D:/SteamLibrary; targeted scan with enumeration disabled worked. Prism keeps core Java game binaries outside the instance, so the generic scanner cannot correctly infer Java from that nearly empty instance. mmc-pack.json and official Mojang metadata confirm Java 1.21.4.

## Publication gates
No listing, upload or publication yet. Require real gameplay validation, multiplayer host/join test, packaged launch recipe passing Melty checks, user-selected listing/license/remix, gameplay screenshot, Melty Test and final user authorization.

## Local Isaac art experiment (2026-10-05)
User requested art from their owned Isaac installation. The included official ResourceExtractor works with forward-slash absolute paths; backslash-path attempts crashed. Base graphics and animations were extracted in work only. Isaac source files were unchanged.

local-art.json is the source of truth for five initial mappings; make_local_art.py validates every field, source and crop bounds before creating a private resource pack. PNG alpha is preserved, without resampling: tears 32x32; bomb first atlas cell 32x32 (source 160x192); backdrop atlas 468x468 supplies 32x32 floor and 16x16 masonry samples. This is an initial visual experiment, not complete environment art or mob animation conversion.

The local pack replaces resources.zip only in the separate IsaacCraft Prism test world. No extracted assets are included in the distributable development archives. A public owner-side asset conversion workflow on Melty remains unverified; publication is blocked until supported or licensed replacement art is used.
Visual check passed in Minecraft 1.21.4: Isaac tears and bomb icons visible in hotbar; brown Basement wall and doorway samples visible; no missing-texture errors found in the current log. Real game-only F2 capture saved as local-isaac-art-gameplay.png. Cellar sample has not yet been visually inspected. This is an initial partial texture pass, not a complete Isaac reskin.

## Procedural expansion (2026-10-05)
User requested items, randomly generated dungeons and Isaac enemies. Added nine collectible rows, a 25-cell grid and a runtime generation row. Each restart grows a connected seven-room tree with six edges, selects the deepest available boss frontier, makes treasure/secret leaves, and varies cover. Generated edge functions manage combat seals and secret entrances. It is assembled from room templates, not arbitrary generated terrain.

Nine adapted collectibles now have inventory keepsakes and local Isaac icons. 20/20 fires two rays, Cupid's Arrow tracks already-hit targets while piercing, and Common Cold applies five-second poison. Existing stat upgrades retain their caps. Unique tear modifiers reroll to stackable rewards after acquisition.

Added Gaper, spider/Crawler, four-way Clotty and Monstro (telegraphed stomp and eight-way volley) using Minecraft hitboxes/AI plus camera-facing item-display sprites. Local converter uses original Isaac sprite crops; Gaper body/head placement was read from 010.001_gaper.anm2. Sprites are static, not full Isaac animations. Public fallback uses Minecraft item placeholders and contains no extracted art.

Verification: 407 sheet cells/type checks and references passed. Official server: 11/11 checks covering eight rerolls, seven rooms/six corridors per floor, bomb-secret opening at generated position, Monstro health/passenger, Clotty volley. Console harness now waits on command completion markers; initial short timing windows caused false negatives, resolved without changing generation. Fixed apostrophe escaping in collectible SNBT and explicit text-display alignment/transforms.

Real integrated client: 12 checks passed (piercing damage on two targets; poison assignment and damage; double shot; generated-room entry; combat door seal/open; room clear; inventory collectible; generated boss entry; boss volley; floor complete). These controlled tests used temporary resistance, static targets and scripted kills and do not demonstrate balance or four-player operation. Screenshot isaac-enemies-gameplay.png shows the four sprites running in Minecraft. Test helpers are removed from the local world after verification and never packaged. Public release gates still pending.
