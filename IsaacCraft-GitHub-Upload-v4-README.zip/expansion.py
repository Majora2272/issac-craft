"""Runtime dungeon assembly and collectible/enemy systems, generated from sheets."""
def expand(S,FUN,fn,j,txt,title,C):
    rooms={r['id']:r for r in S['rooms']}; grid={r['id']:r for r in S['grid']}
    cfg=S['generation'][0]; Y=C['floor_y']; R=C['room_radius']; H=C['ceiling_y']-Y
    def rel(n): return '~'+str(n) if n else '~'
    def rf(x,y,z,a,b,c,block): return 'fill '+' '.join(map(rel,(x,y,z,a,b,c)))+' minecraft:'+block
    def atroom(r,cmd): return f'execute at @e[tag=ic.r_{r},limit=1] run {cmd}'
    extra=['occupied','parent','depth','gen','double','piercing','poison','poisoned','shot','age','edge']
    FUN['load']=[*(f'scoreboard objectives add ic.{s} dummy' for s in extra),*FUN['load']]
    FUN['load'].insert(0,'data modify storage ic:version build set value "procedural-0.2"')
    # Clean every old cell and corridor, then grow a connected tree on the grid.
    start=grid[cfg['start']]
    reset=[s for s in FUN['restart'] if s.startswith(('gamerule ','time ','weather ','difficulty ','setworldspawn ','kill ','bossbar '))]
    reset+=['forceload add -64 -64 64 64','kill @e[tag=ic.entity]']
    for x in range(cfg['clear_min'],cfg['clear_max']+1,16):
        reset.append(f'fill {x} {Y-2} {cfg["clear_min"]} {min(x+15,cfg["clear_max"])} {Y+H+1} {cfg["clear_max"]} air')
    for cell in grid.values():
        reset += [f'summon marker {cell["x"]} {Y+1} {cell["z"]} {{Tags:["ic.entity","ic.cell","ic.{cell["id"]}"]}}']
    reset+=['scoreboard players set @e[tag=ic.cell] ic.occupied 0','scoreboard players set @e[tag=ic.cell] ic.depth 0','scoreboard players set #placed ic.gen 0',f'execute as @e[tag=ic.{start["id"]},limit=1] at @s run function ic:grid/{start["id"]}/activate']
    for index,rid in enumerate(cfg['order'][1:],1):
        reset += [f'scoreboard players set #placed ic.gen {index}']
        if rooms[rid]['kind']=='boss' and cfg['boss_farthest']:
            reset += ['scoreboard players set #deepest ic.depth 0','execute as @e[tag=ic.frontier] if score @s ic.depth > #deepest ic.depth run scoreboard players operation #deepest ic.depth = @s ic.depth','execute as @e[tag=ic.frontier] if score @s ic.depth = #deepest ic.depth run tag @s add ic.candidate','execute as @e[tag=ic.candidate,sort=random,limit=1] at @s run function ic:grid/dispatch','tag @e[tag=ic.candidate] remove ic.candidate']
        else: reset += ['execute as @e[tag=ic.frontier,sort=random,limit=1] at @s run function ic:grid/dispatch']
    reset += ['scoreboard players set #built ic.state 1','scoreboard players set #active ic.room -1','scoreboard players set #secret ic.state 0','scoreboard players add #run ic.runid 1','scoreboard players set #clock ic.timer 0','tag @a remove ic.player','gamemode survival @a','clear @a','tp @a 0 65 3 180 0','scoreboard players set @a ic.restart 0','execute as @a run function ic:init',*title('BASEMENT I','A new descent. Find Monstro.')]
    fn('restart',reset)
    fn('grid/dispatch',[f'execute if entity @s[tag=ic.{c}] run function ic:grid/{c}/activate' for c in grid])
    for number,(cid,cell) in enumerate(grid.items()):
        activate=['tag @s remove ic.frontier','scoreboard players set @s ic.occupied 1',f'scoreboard players set #current ic.parent {number}']
        activate += [f'execute if score #placed ic.gen matches {i} run function ic:place/{rid}' for i,rid in enumerate(cfg['order'])]
        for nid in cell['neighbors']:
            parentnum=list(grid).index(nid)
            activate += [f'execute if score #placed ic.gen matches 1.. if score @s ic.parent matches {parentnum} run function ic:edge/{cid}_{nid}/build']
        # Only entrance and combat rooms expand the frontier, so optional rooms stay leaves.
        for i,rid in enumerate(cfg['order']):
            if rooms[rid]['kind'] not in ('safe','combat'):continue
            activate += [f'execute if score #placed ic.gen matches {i} run function ic:grid/{cid}/expand']
        fn(f'grid/{cid}/activate',activate)
        expand=[]
        for nid in cell['neighbors']:
            selector=f'@e[tag=ic.{nid},tag=!ic.frontier,scores={{ic.occupied=0}},limit=1]'
            expand += [f'execute as {selector} run scoreboard players operation @s ic.parent = #current ic.parent',f'execute as {selector} run scoreboard players operation @s ic.depth = @e[tag=ic.{cid},limit=1] ic.depth',f'execute as {selector} run scoreboard players add @s ic.depth 1',f'tag {selector} add ic.frontier']
        fn(f'grid/{cid}/expand',expand)
    # Room templates are placed relative to their chosen grid marker.
    for rid,r in rooms.items():
        inner=R-1-C['wall_lining']
        lines=[f'tag @s add ic.r_{rid}',f'scoreboard players set #{rid} ic.state 0',rf(-R,-3,-R,R,H,R,'bedrock'),rf(-R+1,-2,-R+1,R-1,H-1,R-1,r['palette']),rf(-inner,0,-inner,inner,H-2,inner,'air'),rf(-7,-1,-7,7,-1,7,'polished_andesite'),rf(-5,-1,-5,5,-1,5,'deepslate_tiles'),rf(-2,-1,-2,2,-1,2,'chiseled_stone_bricks')]
        for dx in (-8,8):
            for dz in (-8,8):lines += [rf(dx,0,dz,dx,H-2,dz,'polished_basalt'),f'setblock {rel(dx)} ~2 {rel(dz)} shroomlight']
        # Independently choose cover positions each run, while preserving entrance routes.
        lines += ['execute store result score #cover ic.rand run random value 0..1',f'execute if score #cover ic.rand matches 0 run function ic:cover/a',f'execute if score #cover ic.rand matches 1 run function ic:cover/b']
        scale=C['label_scale']
        lines += [f'summon text_display ~ ~4 ~ {{Tags:["ic.entity"],billboard:"center",text:\'{txt(r["name"],"#e4cda1")}\',alignment:"{C["label_alignment"]}",background:0,shadow:1b,view_range:0.7f,transformation:{{scale:[{scale}f,{scale}f,{scale}f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}}}']
        if r['kind']=='safe':lines+=['setblock ~-3 ~ ~6 crafting_table','setblock ~-2 ~ ~6 furnace',rf(3,0,6,3,2,6,'oak_log')]
        if r['kind'] in ('treasure','secret'):lines+=['setblock ~ ~ ~ gilded_blackstone','setblock ~ ~1 ~ enchanting_table']
        fn(f'place/{rid}',lines)
    for name,points in [('a',[(-5,4),(5,-4)]),('b',[(-4,-4),(4,4)])]:
        fn('cover/'+name,[v for x,z in points for v in [rf(x,0,z,x+1,1,z+1,'cobblestone'),f'setblock {rel(x)} ~1 {rel(z)} coal_ore',f'setblock {rel(x+1)} ~ {rel(z)} iron_ore']])
    # A corridor marker owns its two room tags, closure and bomb-secret entrance.
    open_dispatch=[]; close_dispatch=[]
    for cid,a in grid.items():
        for nid in a['neighbors']:
            b=grid[nid]; eid=f'{cid}_{nid}'; x=(a['x']+b['x'])//2; z=(a['z']+b['z'])//2; vertical=a['x']==b['x']
            dx,dz=(1,3) if vertical else (3,1)
            box=f'{x-dx} {Y+1} {z-dz} {x+dx} {Y+4} {z+dz}'
            fn(f'edge/{eid}/open',[f'fill {box} air'])
            fn(f'edge/{eid}/close',[f'fill {box} bedrock'])
            open_dispatch += [f'execute if entity @s[tag=ic.e_{eid}] run function ic:edge/{eid}/open']
            close_dispatch += [f'execute if entity @s[tag=ic.e_{eid}] run function ic:edge/{eid}/close']
            ex,ez=(1,0) if vertical else (0,1)
            lines=[f'fill {x-dx-ex} {Y-1} {z-dz-ez} {x+dx+ex} {Y+H} {z+dz+ez} bedrock',f'fill {x-dx} {Y} {z-dz} {x+dx} {Y} {z+dz} polished_blackstone_bricks',f'fill {box} air',f'summon marker {x} {Y+1} {z} {{Tags:["ic.entity","ic.door","ic.newdoor","ic.e_{eid}"]}}']
            for rid in rooms:
                lines += [f'execute if entity @s[tag=ic.r_{rid}] run tag @e[tag=ic.newdoor] add ic.d_{rid}',f'execute if entity @e[tag=ic.{nid},tag=ic.r_{rid}] run tag @e[tag=ic.newdoor] add ic.d_{rid}']
            lines += ['execute if entity @s[tag=ic.r_secret] run tag @e[tag=ic.newdoor] add ic.secret_door',f'execute if entity @s[tag=ic.r_secret] run fill {box} bedrock']
            for sign in (-1,1):
                bx,bz=(x,z+sign*3) if vertical else (x+sign*3,z)
                sx,sz=(1,0) if vertical else (0,1)
                lines += [f'execute if entity @s[tag=ic.r_secret] run fill {bx-sx} {Y+1} {bz-sz} {bx+sx} {Y+3} {bz+sz} cracked_stone_bricks']
            lines += ['tag @e[tag=ic.newdoor] remove ic.newdoor']
            fn(f'edge/{eid}/build',lines)
    fn('door/open',open_dispatch);fn('door/close',close_dispatch)
    # Replace fixed-coordinate triggers and encounters.
    tick=FUN['tick']
    tick=[line for line in tick if not any(f'ic:room/{rid}/' in line for rid in rooms)]
    for rid,r in rooms.items():
        if r['kind'] in ('combat','boss'):
            tick += [f'execute if score #active ic.room matches -1 if score #{rid} ic.state matches 0 at @e[tag=ic.r_{rid},limit=1] positioned ~-8 ~ ~-8 if entity @a[tag=ic.player,gamemode=survival,dx=16,dy=6,dz=16] run function ic:room/{rid}/start',f'execute if score #active ic.room matches {r["index"]} unless entity @e[tag=ic.enemy] run function ic:room/{rid}/clear']
            fn(f'room/{rid}/start',[atroom(rid,f'function ic:room/{rid}/start_here')])
            lines=[f'scoreboard players set #active ic.room {r["index"]}',f'scoreboard players set #{rid} ic.state 1','tp @a[tag=ic.player] ~ ~ ~6 180 0',f'execute as @e[tag=ic.d_{rid},tag=!ic.secret_door] at @s run function ic:door/close',*title(r['name'],'Clear the room. Collect your own reward.')]
            for i in range(r['count']):lines += [f'execute positioned {rel(-4+i*3)} ~ ~-4 run function ic:enemy/{r["enemy"]}']
            if r['kind']=='combat':
                lines += ['scoreboard players set #players ic.count 0','execute as @a[tag=ic.player] run scoreboard players add #players ic.count 1']
                for n in range(2,C['max_players']+1):lines += [f'execute if score #players ic.count matches {n}.. positioned ~5 ~ {rel(-5+n*2)} run function ic:enemy/{r["enemy"]}']
            else:lines += ['bossbar set ic:boss name {"text":"MONSTRO"}','bossbar set ic:boss visible true','bossbar set ic:boss players @a',f'bossbar set ic:boss max {next(e["health"] for e in S["enemies"] if e["id"]==r["enemy"])}']
            fn(f'room/{rid}/start_here',lines)
            fn(f'room/{rid}/clear',[atroom(rid,f'function ic:room/{rid}/clear_here')])
            lines=[f'scoreboard players set #{rid} ic.state 2','scoreboard players set #active ic.room -1',f'execute as @e[tag=ic.d_{rid},tag=!ic.secret_door] at @s run function ic:door/open','kill @e[tag=ic.bullet]','execute as @a[tag=ic.player,gamemode=spectator] run function ic:revive','tp @a[tag=ic.player] ~ ~ ~4','execute as @a[tag=ic.player] run function ic:reward',*title('ROOM CLEARED','A collectible for every soul.','#a2d4b0')]
            if r['kind']=='boss':lines+=['bossbar set ic:boss visible false',*title('BASEMENT CLEARED','/trigger ic.restart rolls a new dungeon.','#eed395')]
            fn(f'room/{rid}/clear_here',lines)
        if r['kind'] in ('treasure','secret'):
            tick += [f'execute at @e[tag=ic.r_{rid},limit=1] positioned ~-8 ~ ~-8 as @a[tag=ic.player,gamemode=survival,dx=16,dy=6,dz=16,tag=!ic.{rid}] run function ic:room/{rid}/treasure']
    fn('explode',['execute as @e[tag=ic.secret_door,distance=..6] at @s run function ic:secret_open','summon tnt ~ ~ ~ {fuse:0}','kill @s'])
    fn('secret_open',['function ic:door/open','tag @s remove ic.secret_door','scoreboard players set #secret ic.state 1',*title('A HIDDEN WAY','Something waits behind the cracks.','#d7a5e6')])
    FUN['init'] += [f'scoreboard players set @s ic.{s} 0' for s in ('double','piercing','poison')]
    FUN['init']=[line.replace('Cracked northern walls may hide secrets.','Cracked walls may hide secrets.') for line in FUN['init']]
    for item in S['items']:
        itemdata={'text':item['description'],'color':'gray','italic':False}
        name=txt(item['name'],item['color']).replace("'","\\'")
        lore=j(itemdata).replace("'","\\'")
        note=j({'text':'Passive for this run. Keepsake item.','color':'dark_gray','italic':False})
        FUN['item/'+item['id']].insert(0,f'give @s paper[minecraft:custom_name=\'{name}\',minecraft:lore=[\'{lore}\',\'{note}\'],minecraft:item_model="ic:collectible/{item["id"]}",minecraft:custom_data={{ic_collectible:1b}}]')
    FUN['reward'][1:1]=[f'execute if score @s ic.rand matches {item["index"]} if score @s {item["stat"]} matches {item["cap"]}.. store result score @s ic.rand run random value 0..5' for item in S['items'] if item['stat'] in ('ic.double','ic.piercing','ic.poison')]
    # Each ray tracks which enemies it has hit, allowing piercing without repeated hits.
    base=FUN['shoot']
    raycall='execute anchored eyes positioned ^ ^ ^0.6 run function ic:ray'
    fn('shoot',[base[0],'execute if score @s ic.double matches 0 run function ic:shoot_one','execute if score @s ic.double matches 1.. rotated ~-6 ~ run function ic:shoot_one','execute if score @s ic.double matches 1.. rotated ~6 ~ run function ic:shoot_one',base[-1]])
    fn('shoot_one',['scoreboard players set @s ic.step 0','scoreboard players set @s ic.hit 0','tag @e[tag=ic.struck] remove ic.struck','tag @e[tag=ic.target] remove ic.target',raycall])
    FUN['ray']=[line.replace('tag=ic.enemy,','tag=ic.enemy,tag=!ic.struck,') for line in FUN['ray']]
    FUN['hit']=[line.replace('tag=ic.enemy,','tag=ic.enemy,tag=!ic.struck,') for line in FUN['hit'][:-1]]+['tag @e[tag=ic.target] add ic.struck','execute if score @s ic.poison matches 1.. run scoreboard players set @e[tag=ic.target] ic.poisoned 100','execute if score @s ic.piercing matches 1.. run scoreboard players set @s ic.hit 0','tag @e[tag=ic.target] remove ic.target']
    # Enemy bodies remain Minecraft hitboxes; local resource pack supplies Isaac sprites.
    for e in S['enemies']:
        attrs=[{'id':'minecraft:max_health','base':e['health']},{'id':'minecraft:movement_speed','base':e['speed']},{'id':'minecraft:attack_damage','base':e['damage']},{'id':'minecraft:scale','base':e['scale']}]
        sprite={'id':'minecraft:item_display','Tags':['ic.entity','ic.sprite'],'billboard':'vertical','item':{'id':'minecraft:paper','count':1,'components':{'minecraft:item_model':'ic:enemy/'+e['id']}},'item_display':'fixed','transformation':{'scale':[e['sprite_scale']]*3,'translation':[0,e['sprite_y'],0],'left_rotation':[0,0,0,1],'right_rotation':[0,0,0,1]}}
        # JSON numeric arrays need float SNBT for display transformations.
        sn=j(sprite)
        for key in ('scale','translation','left_rotation','right_rotation'):
            values=sprite['transformation'][key];sn=sn.replace(j(values),'['+','.join(f'{float(n)}f' for n in values)+']')
        tags=['ic.entity','ic.enemy','ic.newenemy','ic.kind_'+e['id']]+(['ic.boss'] if e['behavior']=='stomp' else [])
        nbt='{Tags:'+j(tags)+',PersistenceRequired:1b,Health:'+str(e['health'])+'f,CustomName:\''+txt(e['name'],e['color'])+'\',CustomNameVisible:1b,attributes:'+j(attrs)+',Passengers:['+sn+']'+(',NoAI:1b' if e['behavior']=='radial' else '')+'}'
        fn('enemy/'+e['id'],[f'summon {e["entity"]} ~ ~ ~ {nbt}','effect give @e[tag=ic.newenemy] invisibility infinite 0 true','scoreboard players set @e[tag=ic.newenemy] ic.timer 0','scoreboard players set @e[tag=ic.newenemy] ic.shot 0','scoreboard players set @e[tag=ic.newenemy] ic.poisoned 0','tag @e[tag=ic.newenemy] remove ic.newenemy'])
        if e['shot_interval']:
            fn('enemy_tick/'+e['id'],['scoreboard players add @s ic.shot 1',f'execute if score @s ic.shot matches {e["shot_interval"]-12} run particle minecraft:angry_villager ~ ~1 ~ 0.3 0.3 0.3 0 3 force',f'execute if score @s ic.shot matches {e["shot_interval"]}.. run function ic:volley/{e["id"]}'])
            tick += [f'execute as @e[tag=ic.kind_{e["id"]}] at @s run function ic:enemy_tick/{e["id"]}']
            volley=['scoreboard players set @s ic.shot 0','playsound minecraft:entity.slime.attack hostile @a[distance=..24] ~ ~ ~ 0.7 0.7']
            for yaw in range(0,360,45 if e['behavior']=='stomp' else 90):
                volley += [f'summon marker ~ ~0.7 ~ {{Tags:["ic.entity","ic.bullet","ic.bullet_{e["id"]}","ic.newbullet"],Rotation:[{yaw}f,0f]}}','scoreboard players set @e[tag=ic.newbullet] ic.age 0','tag @e[tag=ic.newbullet] remove ic.newbullet']
            fn('volley/'+e['id'],volley)
            fn('bullet/'+e['id'],['scoreboard players add @s ic.age 1',f'tp @s ^ ^ ^{e["bullet_speed"]}','particle minecraft:dust{color:[0.8,0.05,0.05],scale:1.5} ~ ~ ~ 0 0 0 0 1 force',f'execute as @a[tag=ic.player,gamemode=survival,distance=..1] run damage @s {e["bullet_damage"]} minecraft:mob_projectile','execute if entity @a[tag=ic.player,gamemode=survival,distance=..1] run kill @s','execute unless block ~ ~ ~ #ic:ray_pass run kill @s',f'execute if score @s ic.age matches {e["bullet_life"]}.. run kill @s'])
            tick += [f'execute as @e[tag=ic.bullet_{e["id"]}] at @s run function ic:bullet/{e["id"]}']
    # Keep attached billboards only while their mob exists, and apply poison pulses.
    tick += ['tag @e[tag=ic.sprite] add ic.orphan','execute as @e[tag=ic.enemy] on passengers run tag @s remove ic.orphan','kill @e[tag=ic.orphan]','scoreboard players remove @e[tag=ic.enemy,scores={ic.poisoned=1..}] ic.poisoned 1','execute as @e[tag=ic.enemy,scores={ic.poisoned=1..}] at @s run particle minecraft:entity_effect{color:[0.4,0.8,0.1,1.0]} ~ ~1 ~ 0.3 0.3 0.3 0 1 force']
    FUN['second'] += ['execute as @e[tag=ic.enemy,scores={ic.poisoned=1..}] run damage @s 1 minecraft:magic']
    FUN['tick']=tick
