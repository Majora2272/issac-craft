"""Convert locally extracted, owned Isaac art. Never distribute the output pack.
Usage: python make_local_art.py EXTRACTED_RESOURCES OUTPUT_ZIP
Requires Pillow. Input is the directory containing gfx/. No game data is bundled.
"""
import io, json, sys, zipfile
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parent
source, output = map(Path, sys.argv[1:3])
rows = json.loads((root/'local-art.json').read_text())
errors = []
for row in rows:
    for column in ('id','source','crop','kind','target','canvas','offset'):
        if not row.get(column): errors.append(f'{row.get("id")}.{column}: empty')
    path = source/row['source']
    if not path.is_file():
        errors.append(f'{row["id"]}: missing {path}')
        continue
    with Image.open(path) as im:
        x,y,r,b = row['crop']
        if not (0 <= x < r <= im.width and 0 <= y < b <= im.height):
            errors.append(f'{row["id"]}: crop outside source')
    if row['kind'] not in ('item','texture'): errors.append(f'{row["id"]}: unknown kind')
    for layer in row.get('layers',[]):
        lp=source/layer['source']
        if not lp.is_file():errors.append(f'{row["id"]}: missing layer {lp}')
        else:
            with Image.open(lp) as im:
                x,y,r,b=layer['crop']
                if not (0<=x<r<=im.width and 0<=y<b<=im.height):errors.append(f'{row["id"]}: invalid layer crop')
if errors: sys.exit('\n'.join(errors))
print('Local art preflight: all cells filled; sources and crop bounds verified.')
with zipfile.ZipFile(root/'IsaacCraft-Resources-dev.zip') as base:
    files = {n:base.read(n) for n in base.namelist()}
files['pack.mcmeta'] = json.dumps({'pack':{'pack_format':46,'description':'IsaacCraft • LOCAL Isaac art • do not redistribute'}}).encode()
for row in rows:
    im = Image.new('RGBA',tuple(row['canvas']))
    for layer in row.get('layers',[]):
        im.alpha_composite(Image.open(source/layer['source']).convert('RGBA').crop(layer['crop']),tuple(layer['offset']))
    im.alpha_composite(Image.open(source/row['source']).convert('RGBA').crop(row['crop']),tuple(row['offset']))
    data = io.BytesIO(); im.save(data,format='PNG')
    if row['kind'] == 'item':
        files[f'assets/ic/textures/item/{row["id"]}.png'] = data.getvalue()
        files[f'assets/ic/models/item/{row["target"]}.json'] = json.dumps({'parent':'minecraft:item/generated','textures':{'layer0':f'ic:item/{row["id"]}'}}).encode()
    else:
        files[f'assets/minecraft/textures/block/{row["target"]}.png'] = data.getvalue()
output.parent.mkdir(parents=True,exist_ok=True)
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as pack:
    for name,data in files.items(): pack.writestr(name,data)
print(f'Wrote {len(rows)} local art mappings to {output}. Runtime appearance still needs checking.')
